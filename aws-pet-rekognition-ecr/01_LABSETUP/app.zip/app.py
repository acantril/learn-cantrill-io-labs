from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import boto3
import os

# Set up the Flask app
app = Flask(__name__)

# Set up the Amazon S3 client
s3 = boto3.client('s3', region_name='us-east-1')

rekognition = boto3.client('rekognition', region_name='us-east-1')

# AWS S3 bucket configuration
BUCKET_NAME = os.environ.get("BUCKET_NAME")
# AWS Rekognition model configuration
MODEL_ARN = os.environ.get("MODEL_ARN")


@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if "file" not in request.files:
            msg = "No file selected"
            return render_template("index.html", msg=msg)

        file = request.files["file"]

        if file.filename == "":
            msg = "No file selected"
            return render_template("index.html", msg=msg)

        filename = secure_filename(file.filename)
        s3.upload_fileobj(file, BUCKET_NAME, filename)

        labels = rekognition.detect_custom_labels(
            ProjectVersionArn=MODEL_ARN,
            Image={
                'S3Object': {
                    'Bucket': BUCKET_NAME,
                    'Name': filename,
                }
            }
        )['CustomLabels']
        return render_template("index.html", labels=labels, prediction=True)

    return render_template("index.html")

if __name__ == '__main__':
  app.run()